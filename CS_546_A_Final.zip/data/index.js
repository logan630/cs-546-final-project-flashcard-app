const userData=require('./users')
const deckData=require('./decks')
const folderData=require('./folders')

module.exports = {
    users: userData,
    decks: deckData,
    folders: folderData
}