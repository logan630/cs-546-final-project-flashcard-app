# cs-546-final-project-flashcard-app
Final project for cs546 at Stevens Institute of Technology. A simple learning tool that makes use of user-created flashcards as a study aid.

How to run seed file:

It is located in tasks/seed.js Type "npm run seed" to seed the data. Login credentials are given in the seed file. If necessary, do npm install seed. The seed file supplies some decks and numerous cards When that is done, do npm start to start the project.

The mongo exported json files will also be provided

github link: https://github.com/logan630/cs-546-final-project-flashcard-app


NOTE: The file submitted is not the most recent, but it is correct. The github may not be fully up to date. This zip file is.